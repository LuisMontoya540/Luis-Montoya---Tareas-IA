/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arbolbinario;

/**
 *
 * @author luisg
 */


public class ArbolBinario {
    public static void main(String[] args) {
        Arbol arbol = new Arbol();

        System.out.println("¿Está vacío al inicio? " + arbol.vacio());

        arbol.insertar("Carlos");
        arbol.insertar("Ana");
        arbol.insertar("Luis");
        arbol.insertar("Beatriz");
        arbol.insertar("Elena");

        System.out.println("¿Está vacío después de insertar? " + arbol.vacio());
        System.out.println("");
        System.out.println("Buscar el nodo Beatriz:");
        Nodo encontrado = arbol.buscarNodo("Beatriz");
        System.out.println("Resultado de busqueda 'Beatriz': " + encontrado);
        System.out.println("");
        System.out.println("Intento de busqueda de un nodo no existente:");
        Nodo noEncontrado = arbol.buscarNodo("Zoe");
        System.out.println("Resultado de busqueda 'Zoe': " + noEncontrado);
    }
}