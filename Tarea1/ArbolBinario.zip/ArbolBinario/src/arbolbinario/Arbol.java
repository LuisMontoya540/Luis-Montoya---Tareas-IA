/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arbolbinario;

/**
 *
 * @author luisg
 */
public class Arbol {
    private Nodo raiz;

    public Arbol() {
        this.raiz = null;
    }

    // Verifica si el árbol está vacío
    public boolean vacio() {
        return raiz == null;
    }

    // Inserta un nuevo nodo respetando el orden del Árbol Binario de Búsqueda
    public void insertar(String nombre) {
        raiz = insertarRecursivo(raiz, nombre);
    }

    private Nodo insertarRecursivo(Nodo actual, String nombre) {
        if (actual == null) {
            return new Nodo(nombre);
        }

        int comparacion = nombre.compareToIgnoreCase(actual.nombre);
        if (comparacion < 0) {
            actual.izquierdo = insertarRecursivo(actual.izquierdo, nombre);
        } else if (comparacion > 0) {
            actual.derecho = insertarRecursivo(actual.derecho, nombre);
        }
        // Si comparacion == 0, ya existe el nombre y no se duplica
        return actual;
    }

    // Busca un nodo por nombre recorriendo el Árbol Binario de Búsqueda
    public Nodo buscarNodo(String nombre) {
        return buscarRecursivo(raiz, nombre);
    }

    private Nodo buscarRecursivo(Nodo actual, String nombre) {
        if (actual == null) {
            return null;
        }

        int comparacion = nombre.compareToIgnoreCase(actual.nombre);
        if (comparacion == 0) {
            return actual;
        } else if (comparacion < 0) {
            return buscarRecursivo(actual.izquierdo, nombre);
        } else {
            return buscarRecursivo(actual.derecho, nombre);
        }
    }
}
